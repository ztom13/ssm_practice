create view "empview" as
  select "EMPNO","ENAME","JOB","MGR","HIREDATE","SAL","COMM","DEPTNO" from emp where deptno =20 WITH READ ONLY
/

